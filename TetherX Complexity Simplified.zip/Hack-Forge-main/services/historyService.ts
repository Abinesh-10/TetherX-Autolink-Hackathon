
import { AnalysisResult } from '../types';

const STORAGE_KEY = 'aida_analysis_history';

export const saveAnalysis = (result: AnalysisResult) => {
  const history = getHistory();
  const updated = [result, ...history].slice(0, 5);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
};

export const getHistory = (): AnalysisResult[] => {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) return [];
  try {
    return JSON.parse(stored);
  } catch {
    return [];
  }
};
